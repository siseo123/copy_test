package com.example.whateat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;


public class ALLSelectMenu extends AppCompatActivity {

    ArrayList <String> allMenu2=new ArrayList<>();
    private LinearLayout container;
    TextView[] qqqqq;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allselect_menu);

        Intent it = getIntent();
        allMenu2 = it.getStringArrayListExtra("AllMenuList2");

        qqqqq=new TextView[allMenu2.size()];


        for(int i=0; i<allMenu2.size();i++){
            container = (LinearLayout) findViewById(R.id.layout);
            MenuList(allMenu2.get(i),i);

        }



    }


    private void MenuList(String s,int i) {

        qqqqq[i] = new TextView(this);
        qqqqq[i].setText(s);
        qqqqq[i].setTextSize(45);
        qqqqq[i].setTextColor(Color.BLACK);
        qqqqq[i].setId(i);
        qqqqq[i].getTag(i);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        lp.gravity = Gravity.CENTER;
        qqqqq[i].setLayoutParams(lp);



        container.addView(qqqqq[i]);


    }


    public void on_Click_sub(View v){
        Intent intent = new Intent(this, MainActivity.class);
        setResult(RESULT_OK, intent);
        finish();
    }
}