package com.example.whateat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ChoiceMenuMain extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener{
    private LinearLayout container;
    private static final float FONT_SIZE = 50;
    //private String cs1;
    ListView listView;

    TextView tv;
    String result = "";


    String[] qqqqq0;    //최종 전달될 배열
    CheckBox[] qqqqq;//메인 체크박스의 배열
    CheckBox[] qqqqq2;//밑에 체크된 음식들의 이름을 저장. 없어도 무관한데 코드 수정 귀찮아 일단 보류




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice_menu_main);
        Intent it = getIntent();
        String tag = it.getStringExtra("it_tag");
        int stringId;
        stringId = getResources().getIdentifier(tag,"array",getPackageName());
        String[] myLoc = getResources().getStringArray(stringId);



        qqqqq0 =new String[myLoc.length];
        qqqqq=new CheckBox[myLoc.length];
        qqqqq2=new CheckBox[myLoc.length];
        for(int a=0; a<qqqqq2.length; a++)

        {


            qqqqq2[a]= new CheckBox(this);
        }//전달할 체크박스배열 qqqqq2 생성



         tv=(TextView) findViewById(R.id.result);



        for(int i=0; i<myLoc.length;i++){
            container = (LinearLayout) findViewById(R.id.layout);
            checkbox(myLoc[i],i);

        }//화면의 체크박스들 생성



        tv.setText("선택목록 : "+result);



        for(int a=0;a<myLoc.length;a++)
        {

            qqqqq[a].setOnCheckedChangeListener(this);
        }



    }



    private void checkbox(String s,int i) {


        qqqqq[i]= new CheckBox(this);
        qqqqq[i].setText(s);
        qqqqq2[i].setText(s);//일단 넣어
        qqqqq0[i]=qqqqq[i].getText().toString();//누르는시 바로 저장? 전달하는 객체
        qqqqq[i].setTextSize(FONT_SIZE);
        qqqqq[i].setTextColor(Color.BLACK);
        qqqqq[i].setChecked(true);
        qqqqq[i].setId(i);
        qqqqq[i].getTag(i);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);

        lp.gravity = Gravity.CENTER;
        qqqqq[i].setLayoutParams(lp);



        container.addView(qqqqq[i]);

        result+=qqqqq[i].getText()+" ";

    }



    private void setCheck()
    {

    }



@Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
{

    String result2="";

        for(int a=0; a<qqqqq.length; a++)

        {


            {
                if (qqqqq[a].isChecked()) {
                    qqqqq2[a].setText(qqqqq[a].getText());
                    qqqqq0[a] = qqqqq[a].getText().toString();
                }


                else {
                    qqqqq2[a].setText(null);
                    qqqqq0[a]=null;
                }

            }



            result2 += qqqqq2[a].getText().toString();
            if (qqqqq[a].isChecked())

                result2+=", ";


              /*  if (qqqqq[a].isChecked())

                    result2 += qqqqq2[a].getText().toString() + ", "; 버전 2*/

        }

    tv.setText("선택목록 : "+result2);

    }




    public void on_Click_sub(View v){
        Intent intent = new Intent(this, MainActivity.class);
        String[] myMenu =qqqqq0;
        intent.putExtra("CheckBox", myMenu);
        setResult(RESULT_OK, intent);
        finish();
    }//인텐트 전달용


}