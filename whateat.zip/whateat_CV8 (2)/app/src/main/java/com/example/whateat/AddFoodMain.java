package com.example.whateat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class AddFoodMain extends AppCompatActivity {
    private int SIZE = 99; //<-- 음식 추가 가능 최대 갯수(100개)
    ListView lv;
    ArrayAdapter<String> adapter;
    ArrayList<String> listItem;
    EditText et;
    ImageButton bt;
    ImageButton r_btn;
    ImageButton save_btn;
    String[] items = new String[SIZE];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_food_main);
        et = findViewById(R.id.food_text);
        lv = findViewById(R.id.add_list);
        bt = findViewById(R.id.fAdd);
        r_btn = findViewById(R.id.reset_btn);
        save_btn = findViewById(R.id.save_btn);
        listItem = new ArrayList<String>();
        TextView tv = findViewById(R.id.tv1);

        save_btn.setOnClickListener(new View.OnClickListener() {// 저장 담당 버튼 누를시 룰렛에 추가
            @Override
            public void onClick(View v) {
                if(listItem.size() > 0){
                    for(int i=0;i<listItem.size();i++)
                    {
                        items[i]=listItem.get(i);//<-- Items 문자열배열 안에 리스트목록에 있는 음식들을 추가
                    }
                    Toast.makeText(getApplicationContext(),"룰렛에 추가 되었습니다.",Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getApplicationContext(),"최소 1개의 음식이 추가되어야 합니다.",Toast.LENGTH_LONG).show();
                }



                    Intent intent = new Intent(AddFoodMain.this,MainActivity.class);
                    String[] myMenu =items;
                    intent.putExtra("CheckBox", myMenu);
                    setResult(RESULT_OK, intent);
                    finish();





            }
        });


        r_btn.setOnClickListener(new View.OnClickListener() {// 초기화 담당 버튼
            @Override
            public void onClick(View v) {
                listItem.clear();
                adapter.notifyDataSetChanged();
                tv.setVisibility(View.VISIBLE);
                if(listItem.size() > 0){
                    for(int i=0;i<listItem.size();i++)
                    {
                        items[i] = null;
                    }
                }
                Toast.makeText(getApplicationContext(),"초기화 되었습니다.",Toast.LENGTH_LONG).show();
            }
        });

        bt.setOnClickListener(new View.OnClickListener() {// 입력받은것을 추가 시키는 추가 버튼
            @Override
            public void onClick(View v) {
                if(et.getText().toString().replace(" ","").equals("")){
                    Toast.makeText(getApplicationContext(),"추가하실 음식을 입력해주세요.",Toast.LENGTH_LONG).show();
                }else if(listItem.size()>SIZE) {
                    Toast.makeText(getApplicationContext(),"최대 "+ (SIZE+1) +"개 추가 가능합니다.",Toast.LENGTH_LONG).show();
                }else{
                    if(listItem.contains(et.getText().toString())){
                        Toast.makeText(getApplicationContext(),"중복 등록은 안됩니다.",Toast.LENGTH_LONG).show();
                    }else
                    {
                        tv.setVisibility(View.GONE);
                        listItem.add(et.getText().toString());
                        adapter.notifyDataSetChanged();
                        et.setText("");

                    }
                }

            }
        });
        adapter = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,listItem);
        lv = findViewById(R.id.add_list);
        lv.setAdapter(adapter);
    }



}