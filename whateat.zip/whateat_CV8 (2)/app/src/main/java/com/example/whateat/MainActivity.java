package com.example.whateat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;


public class MainActivity extends AppCompatActivity{


    private static final int GPS_ENABLE_REQUEST_CODE = 1;
    private static final int PERMISSIONS_REQUEST_CODE = 1;
    String[] REQUIRED_PERMISSIONS  = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
    private static final int REQUEST_CODE =100 ;
    String KF[];
    String CF[];
    String JF[];
    String WF[];
    String FF[];
    String AF[];
    String ADDF[];
    String AllMenuList[][];//위 6배열을 합칠 2차원 배열
    TextView Result;//결정된 음식명
    CheckBox ko;
    CheckBox ch;
    CheckBox ja;
    CheckBox we;
    CheckBox fe;
    CheckBox as;
    private GpsTracker gpsTracker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        KF=getResources().getStringArray(R.array.koreaF);
        CF=getResources().getStringArray(R.array.chinaF);
        JF=getResources().getStringArray(R.array.japanF);
        WF=getResources().getStringArray(R.array.westF);
        FF=getResources().getStringArray(R.array.fastF);
        AF=getResources().getStringArray(R.array.asiaF);
        ADDF=new String[100];

        ko=findViewById(R.id.koreaFBT);
        ch=findViewById(R.id.chinaFBT);
        ja=findViewById(R.id.japanFBT);
        we=findViewById(R.id.westFBT);
        fe=findViewById(R.id.fastFBT);
        as=findViewById(R.id.asiaFBT);

        ko.setOnClickListener(CBCL);
        ch.setOnClickListener(CBCL);
        ja.setOnClickListener(CBCL);
        we.setOnClickListener(CBCL);
        fe.setOnClickListener(CBCL);
        as.setOnClickListener(CBCL);
        Result=(TextView)findViewById(R.id.result);





        // 71~75 권한부여 할지말지 설정
        if (!checkLocationServicesStatus()) {
            showDialogForLocationServiceSetting();
        } else {
            checkPermission();
        }

        // 78~81 TextView에 location을 대입하여 주소 나타내고 button에 reload_button을 대입해 클릭해서 위치 동기화
        final TextView textview_address = (TextView) findViewById(R.id.location);

        ImageButton ReloadButton = (ImageButton) findViewById(R.id.reload_button);
        ReloadButton.setOnClickListener(new View.OnClickListener() {
            //83~97 버튼 누를시 지오코딩으로 위도와 경도를 구해 address에 데이터 넘김.
            @Override
            public void onClick(View arg0) {

                gpsTracker = new GpsTracker(MainActivity.this);

                double latitude = gpsTracker.getLatitude();
                double longitude = gpsTracker.getLongitude();

                String address = getCurrentAddress(latitude, longitude);
                textview_address.setText(address);

            }
        });
    }

    public void on_Click(View v)
    {
        int id = v.getId();
        ImageView images = findViewById(id);
        String tag = (String)images.getTag();
        int MenuNum;

        switch (tag)
        {
            case "koreaF":MenuNum=1;
                  break;

            case "chinaF":MenuNum=2;
                break;

            case "japanF":MenuNum=3;
                break;

            case "westF":MenuNum=4;
                break;

            case "fastF":MenuNum=5;
                break;

            case "asiaF":MenuNum=6;
                break;



            default: MenuNum = 0;
                break;

        }


        Intent intent = new Intent(this, ChoiceMenuMain.class);
        intent.putExtra("it_tag",tag);
        startActivityForResult(intent,REQUEST_CODE+MenuNum);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {

            case GPS_ENABLE_REQUEST_CODE:

                //사용자가 GPS 활성 시켰는지 검사
                if (checkLocationServicesStatus()) {
                    if (checkLocationServicesStatus()) {

                        Log.d("@@@", "onActivityResult : GPS 활성화 되있음");
                        checkPermission();
                        return;
                    }
                }

                break;
        }

        if(requestCode == 101){
            if(data != null){

                Arrays.fill(KF, null);
                KF = data.getStringArrayExtra("CheckBox");

                String exe="";
                for (int a=0;a<KF.length;a++)
                {
                    if(KF[a]==null) {
                        exe += "";
                    }
                    else
                        exe+=KF[a]+", ";
                }

                if(KF != null){
                    Toast.makeText(this, "응답으로 받은 데이터 : "+ exe, Toast.LENGTH_LONG).show();

                }
            }
        }

        else if(requestCode == 102){
            if(data != null){

                Arrays.fill(CF, null);
                CF = data.getStringArrayExtra("CheckBox");

                String exe="";
                for (int a=0;a<CF.length;a++)
                {
                    if(CF[a]==null)
                        exe+="";
                    else
                        exe+=CF[a]+", ";
                }

                if(CF != null){
                    Toast.makeText(this, "응답으로 받은 데이터 : "+ exe, Toast.LENGTH_LONG).show();
                }
            }
        }


        else if(requestCode == 103){
            if(data != null){

                Arrays.fill(JF, null);
                JF = data.getStringArrayExtra("CheckBox");

                String exe="";
                for (int a=0;a<JF.length;a++)
                {
                    if(JF[a]==null)
                        exe+="";
                    else
                        exe+=JF[a]+", ";
                }

                if(JF != null){
                    Toast.makeText(this, "응답으로 받은 데이터 : "+ exe, Toast.LENGTH_LONG).show();
                }
            }
        }


        else if(requestCode == 104){
            if(data != null){

                Arrays.fill(WF, null);
                WF = data.getStringArrayExtra("CheckBox");

                String exe="";
                for (int a=0;a<WF.length;a++)
                {
                    if(WF[a]==null)
                        exe+="";
                    else
                        exe+=WF[a]+", ";
                }

                if(WF != null){
                    Toast.makeText(this, "응답으로 받은 데이터 : "+ exe, Toast.LENGTH_LONG).show();
                }
            }
        }

        else if(requestCode == 105){
            if(data != null){

                Arrays.fill(FF, null);
                FF = data.getStringArrayExtra("CheckBox");

                String exe="";
                for (int a=0;a<FF.length;a++)
                {
                    if(FF[a]==null)
                        exe+="";
                    else
                        exe+=FF[a]+", ";
                }

                if(FF != null){
                    Toast.makeText(this, "응답으로 받은 데이터 : "+ exe, Toast.LENGTH_LONG).show();
                }
            }
        }


        else if(requestCode == 106){
            if(data != null){

                Arrays.fill(AF, null);
                AF = data.getStringArrayExtra("CheckBox");

                String exe="";
                for (int a=0;a<AF.length;a++)
                {
                    if(AF[a]==null)
                        exe+="";
                    else
                        exe+=AF[a]+", ";
                }


                if(AF != null){
                    Toast.makeText(this, "응답으로 받은 데이터 : "+ exe, Toast.LENGTH_LONG).show();
                }

            }

        }

        else if(requestCode == 107){
            if(data != null){

                Arrays.fill(ADDF, null);
                ADDF = data.getStringArrayExtra("CheckBox");

                String exe="";
                for (int a=0;a<ADDF.length;a++)
                {
                    if(ADDF[a]==null)
                        exe+="";
                    else
                        exe+=ADDF[a]+", ";
                }


                if(ADDF != null){
                    Toast.makeText(this, "응답으로 받은 데이터 : "+ exe, Toast.LENGTH_LONG).show();
                }

            }

        }







        else if(requestCode==10000)
        {

            Result.setText(data.getStringExtra("Finish")+"(으)로 결정!");

        }
    }





    View.OnClickListener CBCL = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            boolean checked=((CheckBox)v).isChecked();

            switch (v.getId())
            {
                case R.id.koreaFBT:

                    if(checked)
                    {
                        KF=getResources().getStringArray(R.array.koreaF);

                    }
                    else
                    {
                        Arrays.fill(KF, null);


                    }
                    break;

                case R.id.chinaFBT:

                    if(checked)
                    {

                        CF=getResources().getStringArray(R.array.chinaF);

                    }
                    else
                    {
                        Arrays.fill(CF, null);

                    }
                    break;

                case R.id.japanFBT:

                    if(checked)
                    {

                        JF=getResources().getStringArray(R.array.japanF);

                    }
                    else
                    {
                        Arrays.fill(JF, null);

                    }
                    break;

                case R.id.westFBT:

                    if(checked)
                    {

                        WF=getResources().getStringArray(R.array.westF);

                    }
                    else
                    {
                        Arrays.fill(WF, null);

                    }
                    break;

                case R.id.fastFBT:

                    if(checked)
                    {

                        FF=getResources().getStringArray(R.array.fastF);

                    }
                    else
                    {
                        Arrays.fill(FF, null);

                    }
                    break;

                case R.id.asiaFBT:

                    if(checked)
                    {

                        AF=getResources().getStringArray(R.array.asiaF);
                    }
                    else
                    {
                        Arrays.fill(AF, null);

                    }
                    break;





            }

        }
    };





    @Override
    public void onRequestPermissionsResult(int PermRequestCode, @NonNull String[] permission, @NonNull int[] grandResults) {
        super.onRequestPermissionsResult(PermRequestCode, permission, grandResults);

        if (PermRequestCode == PERMISSIONS_REQUEST_CODE && grandResults.length == REQUIRED_PERMISSIONS.length) {
            // 요청 코드 PERMISSIONS_REQUEST_CODE 권한이 정상적으로 부여되었는지 확인
            boolean check_result = true;

            for (int result : grandResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    check_result = false;
                    break;
                }
            }

            // 115~131 권한 설정(check_result의 값에 따라 선택)
            if (check_result) {
                //거부가 아니라면 위치를 설정할 수 있음
            } else {
                // 만얀 권한이 거부가 된다면 2가지 경우로 설명해줌.
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, REQUIRED_PERMISSIONS[0])
                        || ActivityCompat.shouldShowRequestPermissionRationale(this, REQUIRED_PERMISSIONS[1])) {
                    Toast.makeText(MainActivity.this, "권한이 없습니다. 앱을 다시 실행하여 위치 접근 권한을 허용해주세요.", Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "권한이 없습니다. 설정(앱 정보)에서 위치 접근 권한을 확인해주세요. ", Toast.LENGTH_LONG).show();
                }
            }

        }
    }
    void checkPermission(){

        //권한 확인 단계
        // FINE_LOCATION, COARSE_LOCATION이 Manifest에 들어가 있는지 확인
        int hasFineLocationPermission = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION);
        int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION);

        // 권한이 만약 있다면 위치값을 가져올 수 있음.
        if (hasFineLocationPermission == PackageManager.PERMISSION_GRANTED &&
                hasCoarseLocationPermission == PackageManager.PERMISSION_GRANTED) {

        } else {  // 권한 요청을 거부하였다면 다시 권한 요구

            // 사용자가 위치 접근 권한 거부를 했다면
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, REQUIRED_PERMISSIONS[0])) {

                // 다시한번 권한을 요청함.
                ActivityCompat.requestPermissions(MainActivity.this, REQUIRED_PERMISSIONS,
                        PERMISSIONS_REQUEST_CODE);


            } else {
                // 거부한적이 없다면 권한을 다시 바로 요청함.
                ActivityCompat.requestPermissions(MainActivity.this, REQUIRED_PERMISSIONS,
                        PERMISSIONS_REQUEST_CODE);
            }

        }

    }

    public String getCurrentAddress( double latitude, double longitude) {

        //지오코더... GPS를 주소로 변환
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());

        List<Address> addresses;
        // 만약 정상적으로 작동한다면
        try {

            addresses = geocoder.getFromLocation(
                    latitude,
                    longitude,
                    7);
        } catch (IOException ioException) {
            //정상적으로 작동안한다면
            return "지오코더 서비스 오류";
            //GPS가 문제라면
        } catch (IllegalArgumentException illegalArgumentException) {
            return "잘못된 GPS 좌표";

        }


        // 주소가 정상적으로 검색되지 않는다면
        if (addresses == null || addresses.size() == 0) {
            return "주소 미발견";
        }
        Address address = addresses.get(0);
        if (address.getSubLocality() == null) {
            return address.getAdminArea().toString()+" "+ // 도
                    address.getLocality()+" "+ // 시
                    address.getThoroughfare()+" "; //동
        }
        else {
        return address.getAdminArea().toString()+" "+ // 도
                address.getLocality()+" "+ // 시
                address.getSubLocality()+" "+ // 구(구가 안잡히는 곳도 있음)
                address.getThoroughfare()+" "; //동
        }
    }

    private void showDialogForLocationServiceSetting() {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("위치 서비스 비활성화");
        builder.setMessage("앱을 사용하기 위해서는 위치 서비스가 필요합니다.");
        builder.setCancelable(true);
        builder.setPositiveButton("설정", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Intent callGPSSettingIntent
                        = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivityForResult(callGPSSettingIntent, GPS_ENABLE_REQUEST_CODE);
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        builder.create().show();
    }



    public void goto_Roulette(View v){
        Intent rouletteIntent = new Intent(this, rouletteMain.class);
        ArrayList<String> allMenu1= new ArrayList<String>();
        AllMenuList=new String[][]{KF,CF,JF,WF,FF,AF,ADDF};

       for (int x=0;x<7;x++)
       try {

              for (int y=0;y<30;y++)
              {

                  if (AllMenuList[x][y] != null)
                      allMenu1.add(AllMenuList[x][y]);

              }

           }

       catch(Exception e) {

           e.printStackTrace();

           continue;
       }

       while (allMenu1.remove(null));

        if(allMenu1.size()<2)
            Toast.makeText(this, "음식을 두개이상 고르셔야 룰렛이 작동합니다. (현재 갯수) "+allMenu1.size()+"개", Toast.LENGTH_LONG).show();

        else{
        rouletteIntent.putStringArrayListExtra("AllMenuList", allMenu1);
        startActivityForResult(rouletteIntent,10000);}
    }


    public void goto_AddFood(View v)
    {
        Intent addfood=new Intent(this,AddFoodMain.class);

        startActivityForResult(addfood,107);

    }





    public void goto_ALLSelectMenu(View v)
    {
        Intent ASM=new Intent(this,ALLSelectMenu.class);
        ArrayList<String> allMenu1= new ArrayList<String>();

        AllMenuList=new String[][]{KF,CF,JF,WF,FF,AF,ADDF};

        for (int x=0;x<7;x++)
            try {

                for (int y=0;y<30;y++)
                {

                    if (AllMenuList[x][y] != null)
                        allMenu1.add(AllMenuList[x][y]);

                }

            }

            catch(Exception e) {

                e.printStackTrace();

                continue;
            }

            while (allMenu1.remove(null));
            ASM.putStringArrayListExtra("AllMenuList2",allMenu1);

            startActivity(ASM);


    }





    public boolean checkLocationServicesStatus() {
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

}


