package com.example.whateat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.bluehomestudio.luckywheel.LuckyWheel;
import com.bluehomestudio.luckywheel.OnLuckyWheelReachTheTarget;
import com.bluehomestudio.luckywheel.WheelItem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class rouletteMain extends AppCompatActivity {
    private LuckyWheel luckyWheel;
    List<WheelItem> wheelItems;//룰렛에 들어갈 음식칸
    String point;
    String LastPoint=new String();
    ArrayList <String> allMenu2=new ArrayList<>();//모든 음식 배열

   //String[] allMenuLast; 혹시 나중에 쓸수도있는 모든 선택음식[]



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roulette_main);
        luckyWheel = findViewById(R.id.luck_wheel);

        generateWheelItems();



        luckyWheel.setLuckyWheelReachTheTarget(new OnLuckyWheelReachTheTarget() {
            @Override
            public void onReachTarget() {
                WheelItem wheelItem = wheelItems.get(Integer.parseInt(point)-1);

                String money = wheelItem.text;

                Toast.makeText(rouletteMain.this, "최종결정 ! : "+money, Toast.LENGTH_SHORT).show();
            }
        });



        Button start = findViewById(R.id.spin_btn);


        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random random = new Random();
                point = String.valueOf(random.nextInt(allMenu2.size())+1);
                int z=Integer.parseInt(point);//z는 string형인 point를 int형으로 변환.
                LastPoint=allMenu2.get(z-1);//LastPoint에 걸린 음식명을 저장  ex) allMenu2.get(z-1)는 걸린 음식의 배별
                luckyWheel.rotateWheelTo(Integer.parseInt(point));
            }
        });



    }

    private void generateWheelItems() {
        wheelItems = new ArrayList<>();



        Intent it = getIntent();
        allMenu2=it.getStringArrayListExtra("AllMenuList");//최종 음식들의 배열을 allMenu2에 저장



        //allMenuLast=allMenu2.toArray(new String[allMenu2.size()]); 혹시 나중에 쓸수도있는 모든 선택음식[]

        Drawable d = getResources().getDrawable(R.drawable.blank,null);
        Bitmap bitmap = drawableToBitmap(d);



        for(int i=0;i<allMenu2.size();i++)
        try {
            if (allMenu2.get(i)==null)
                continue;


            int red = (int)(Math.random()*255);
            int blue = (int)(Math.random()*255);
            int green = (int)(Math.random()*255);
            wheelItems.add(new WheelItem(Color.rgb(red,blue,green),bitmap,allMenu2.get(i)));
            luckyWheel.addWheelItems(wheelItems);

            }

        catch(Exception e)
        {

            e.printStackTrace();

            continue;
        }


        //배열에있는 음식들을 룰렛에 넣기
    }

    private static Bitmap drawableToBitmap(Drawable drawable) {
        if(drawable instanceof BitmapDrawable){
            return ((BitmapDrawable)drawable).getBitmap();
        }

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),drawable.getIntrinsicHeight(),Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0,0,canvas.getWidth(),canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }


    public void on_Click_sub(View v){

        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("Finish", LastPoint);
        setResult(RESULT_OK, intent);
        finish();
    }//최종 결정된 LastPoint를 전달

    @Override
    public void onBackPressed(){

        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("Finish", "미정");
        setResult(RESULT_OK, intent);
        finish();
    }//백스페이스로 돌아가면 intent에 아무값도 없어 오류가 나 공백을 넣음
}